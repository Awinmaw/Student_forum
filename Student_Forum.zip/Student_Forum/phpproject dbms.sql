-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 01, 2024 at 12:26 PM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.0.28

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `phpproject`
--

-- --------------------------------------------------------

--
-- Table structure for table `adminpost`
--

CREATE TABLE `adminpost` (
  `ID` int(10) NOT NULL,
  `Name` varchar(100) NOT NULL,
  `Topic` varchar(100) NOT NULL,
  `Information` text NOT NULL,
  `Date` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `adminpost`
--

INSERT INTO `adminpost` (`ID`, `Name`, `Topic`, `Information`, `Date`) VALUES
(1, 'Admin1', 'Knowledge Sharing', 'Hello, everyone!', '2024-02-24 17:30:00'),
(2, 'Admin1', 'Breaking News', 'Hello, everyone!', '2024-02-24 17:30:00'),
(3, 'Admin1', 'Contents Sharing', 'Hello, everyone!', '2024-02-24 17:30:00'),
(4, 'Admin1', 'Knowledge Sharing', 'Hello, everyone!', '2024-02-24 17:30:00'),
(5, 'Admin2', 'Breaking News', 'my heart is on fire', '2024-02-25 17:30:00'),
(6, 'Admin1', 'Knowledge Sharing', 'The exam is so close now!', '2024-02-27 17:30:00');

-- --------------------------------------------------------

--
-- Table structure for table `admintable`
--

CREATE TABLE `admintable` (
  `AId` int(20) NOT NULL,
  `AName` varchar(100) NOT NULL,
  `AEmail` varchar(100) NOT NULL,
  `APassword` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `admintable`
--

INSERT INTO `admintable` (`AId`, `AName`, `AEmail`, `APassword`) VALUES
(1, 'Maw Koon Hein', 'mawkoonhein.nov2002@gmail.com', 'IamAdmin'),
(2, 'Pa Pa Win Thwin', 'papa.tp.2020@gmail.com', 'IamAdmin'),
(3, 'Khant Hmu Paing', 'hmuepaingkhant@gmail.com', 'IamAdmin'),
(4, 'Win Pa Pa Min', 'winpapaminminn805@gmail.com', 'IamAdmin'),
(6, 'Minkoyee', 'minkoyee@gmail.com', 'IamAdmin'),
(8, 'Registrar', 'rg23@gamil.com', 'IamAdmin'),
(9, 'Registrar2', 'rgba@gmail.com', 'IamAdmin');

-- --------------------------------------------------------

--
-- Table structure for table `commenttable`
--

CREATE TABLE `commenttable` (
  `CId` int(2) NOT NULL,
  `PostId` varchar(255) DEFAULT NULL,
  `CName` varchar(50) DEFAULT NULL,
  `CPakapata` varchar(7) DEFAULT NULL,
  `CContent` text DEFAULT NULL,
  `CDate` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `commenttable`
--

INSERT INTO `commenttable` (`CId`, `PostId`, `CName`, `CPakapata`, `CContent`, `CDate`) VALUES
(7, '52', 'Jin Wang', 's002081', 'i like to read your opinion', '2024-02-27'),
(8, '52', 'Jin Wang', 's002081', 'i am software developer', '2024-02-27'),
(44, '55', 'Awin', 's002126', 'This is testing', '2024-04-01'),
(52, '57', 'Maw Koon Hein', 's002143', 'this is great', '2024-04-01'),
(53, '57', 'Maw Koon Hein', 's002143', 'this is great', '2024-04-01'),
(57, '57', 'Maw Koon Hein', 's002143', 'Maw koon comment', '2024-04-01'),
(58, '57', 'Maw Koon Hein', 's002143', 'Hello', '2024-04-01'),
(59, '57', 'Khant', '002140', 'hello', '2024-04-01');

-- --------------------------------------------------------

--
-- Table structure for table `posttable`
--

CREATE TABLE `posttable` (
  `PostId` int(255) NOT NULL,
  `Postwriter` varchar(7) NOT NULL,
  `WriterName` varchar(100) NOT NULL,
  `PostTopic` varchar(1000) NOT NULL,
  `PostContent` text NOT NULL,
  `PostDate` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `Status` int(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `posttable`
--

INSERT INTO `posttable` (`PostId`, `Postwriter`, `WriterName`, `PostTopic`, `PostContent`, `PostDate`, `Status`) VALUES
(20, 's002081', 'Khant Hmu Paing', 'web designer', 'i am a webdesigner\r\n			', '2024-02-25 16:27:16', 1),
(23, 's002068', 'Mg Mg', 'school', 'hello everyone\r\n			', '2024-02-25 16:27:16', 1),
(24, 's002143', 'Maw Koon Hein', 'Introduction', 'Hello Everyone!\r\nI am new one.', '2024-02-25 16:27:16', 1),
(28, 's002111', 'Ma Ma', 'Sharing facts', 'hi there!', '2024-02-28 08:21:22', 1),
(29, 's002212', 'Hla Hla', 'Sharing facts', 'Hello!', '2024-02-25 16:27:16', 1),
(30, 's002332', 'Ko Ko', 'Sharing facts', 'Hello!', '2024-02-25 16:27:16', 1),
(31, 's002143', 'Minkoyee', 'Sharing facts', 'Hello!', '2024-02-25 16:27:16', 1),
(32, 's002122', 'Kyaw Kyaw', 'Sharing facts', 'Lalaland', '2024-02-25 16:27:16', 1),
(34, 'Admin', '', 'First Year(First Semester)', 'This is about content.', '2024-02-24 17:30:00', 0),
(35, 'Admin1', '', 'Knowledge Sharing', 'Hello', '2024-02-24 17:30:00', 0),
(45, 's002143', 'Maw Maw Koon Hein', 'Comment', 'Hey', '2024-02-25 16:08:46', 0),
(51, 's002136', 'Khant Hmu Paing', 'math', 'i love to solve math problems', '2024-02-26 06:15:49', 1),
(52, 's999999', 'Aung Thu ta', 'Exam', 'When will the exam start?', '2024-02-26 06:34:29', 1),
(54, 's002346', 'Htet Paing Kyaw', 'Sharing facts', 'I just want share some facts.', '2024-02-27 15:13:56', 1),
(55, 's002126', 'Awin', 'Sharing facts', 'i am so lazy', '2024-02-28 02:38:57', 1),
(56, 's002126', 'Awin', 'Programming Language', 'What is programming language?', '2024-02-28 05:37:15', 0),
(57, 's002126', 'Awin', 'Sharing facts', 'testing', '2024-02-28 08:20:12', 0);

-- --------------------------------------------------------

--
-- Table structure for table `userinfo`
--

CREATE TABLE `userinfo` (
  `UId` int(255) NOT NULL,
  `UName` varchar(100) NOT NULL,
  `UPakapata` varchar(7) DEFAULT NULL,
  `UYear` varchar(100) NOT NULL,
  `UEmail` varchar(100) NOT NULL,
  `UPassword` varchar(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `userinfo`
--

INSERT INTO `userinfo` (`UId`, `UName`, `UPakapata`, `UYear`, `UEmail`, `UPassword`) VALUES
(31, 'Jin Wang', 's002081', 'Third Year', 'jinwang@gmail.com', 'jinwang'),
(32, 'Khant Hmu Paing', 's002136', 'Third Year', 'mhue@gmail.com', 'kmp2003'),
(40, 'Mya Mya', 's222222', 'Final Year', 'myamya@gmail.com', 'myamya'),
(43, 'Pa Pa Win Thwin', 's002126', 'Third Year', 'papa@gmail.com', '2003'),
(44, 'MgMg', '002135', 'Third Year', 'mg@gmail.com', '1111'),
(45, 'Maw Koon Hein', 's002143', 'Third Year(First Semester)', 'maw@gmail.com', '111111'),
(47, 'Aung Thu ta', 's999999', 'First Year', 'thuta@gmail.com', 'thuta'),
(49, 'Htet Paing Kyaw', 's002346', 'Third Year', 'htet@gmail.com', '22222'),
(51, 'Kyaw Thu', 's002204', 'Fourth Year', 'kyaw@gmail.com', '2222'),
(52, 'Hlaing Myat Mon', 's002159', 'Third Year', 'lone@gmail.com', 'lone'),
(54, 'Awin', 's002126', 'Third Year', 'awin@gmail.com', '1111'),
(56, 'Khant', '002140', 'Third Year', 'K@gmail.com', '232323');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `adminpost`
--
ALTER TABLE `adminpost`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `admintable`
--
ALTER TABLE `admintable`
  ADD PRIMARY KEY (`AId`);

--
-- Indexes for table `commenttable`
--
ALTER TABLE `commenttable`
  ADD PRIMARY KEY (`CId`);

--
-- Indexes for table `posttable`
--
ALTER TABLE `posttable`
  ADD PRIMARY KEY (`PostId`);

--
-- Indexes for table `userinfo`
--
ALTER TABLE `userinfo`
  ADD PRIMARY KEY (`UId`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `adminpost`
--
ALTER TABLE `adminpost`
  MODIFY `ID` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `admintable`
--
ALTER TABLE `admintable`
  MODIFY `AId` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `commenttable`
--
ALTER TABLE `commenttable`
  MODIFY `CId` int(2) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=60;

--
-- AUTO_INCREMENT for table `posttable`
--
ALTER TABLE `posttable`
  MODIFY `PostId` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=60;

--
-- AUTO_INCREMENT for table `userinfo`
--
ALTER TABLE `userinfo`
  MODIFY `UId` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=57;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
