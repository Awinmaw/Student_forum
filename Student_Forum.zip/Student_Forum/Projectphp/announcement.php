<?php
  session_start();
  error_reporting(E_ALL);
  ini_set('display_errors', 1); 

	include("dbconn.php");

	if (isset($_POST['submit'])) {
    $searchval = $_POST['search'];

    $query = "SELECT * FROM adminpost WHERE Topic LIKE '%$searchval%' OR Name LIKE '%$searchval%' OR Information LIKE '%$searchval%' ";

    $result = mysqli_query($db, $query);

    if ($result->num_rows > 0) {
        echo '<div id="resultDiv">';
        while ($row = $result->fetch_assoc()) {
            $name = $row['Name'];
            $tp = $row['Topic'];
            $post = $row['Information'];
            $date = $row['Date'];
            
          echo '
                <table border=1 class="table w-75 mt-4 mb-3" style="margin-left: 55px">
                  <tr height=50px>
                    <td width="10px" class="bg-light"><div class="d-inline-block" style="margin-left: 15px; margin-top: 5px; border-radius: 100%;"><img src="./image/default-user.png" style="width:56px;height:56px;object-fit: fill; border: 2px solid #1fd655; border-radius:100%"></div></td>
                    <td class="bg-light"><span style="font-size: 17px;"><b>'.$name.'</b></span><i class="fa-solid fa-ellipsis-vertical text-secondary float-end"></i><br><span style="font-size: 14px; color:#00ab41"><b>( <i>'.$tp.'</i> )</b></span><br><span style="font-size: 10px;" class="float-end"><u>'.$date.'</u></span></td>
                  </tr>
                  <tr height= 200px>
                    <td style="overflow-y:auto; padding: 20px;" colspan=2>'.$post.'</td>
                  </tr>
                </table>';
        }
        echo '</div>';
    } else {
        echo '<script>alert("Result not found")</script>';
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="./fontawesome-free-6.4.2-web/css/all.css">
    <link rel="stylesheet" href="./css/bootstrap.css">
    <style>
      .navbar{height: 70px; background-color: white; border-bottom: 1px solid gray; width: auto;}

      .bot-nav{width: 100%; position: fixed; bottom: 0; border-top: 2px solid gray; background-color: white; height: 45px; z-index: 1;}

      .logo{font-size: 25px; margin-left: 550px; text-shadow: 2px 2px 3px lightgray;}

        .left-top{padding: 25px; height: 370px;}
        .profilepic img{ width: 116px; height: 116px; margin-left: 15px; margin-top: 10px; border-radius: 100%; object-fit:fill;}
        .left-bottom button{width: 300px; font-size: 15px; padding: 10px; border: none; }

        .main-left{height: 800px; overflow-y: auto; overflow-x: hidden; width: 25%; position: fixed; z-index: 2;}
        .main-right{margin-left: 350px;}

        .texttitle{border: 1px solid lightgray; margin-bottom: 20px; border-radius: 20px; height: 35px; width: 340px; margin-left: 10px;}
        .offcanvas-container input{width: 275px; margin-bottom: 10px; border: 1px solid gray;}
        .offcanvas-container select{width: 275px; margin-bottom: 10px; border: 1px solid gray;}
        #find{width:300px; height:45px; margin-top: 4%; z-index: 1;}
        #searchbar{width: 100%; position: fixed; top: 8%; height: 150px; margin-left: 10px;}
        #resultDiv{ width: 30%; height: 330px; position:absolute; border: 2px solid black; border-radius: 5px; left:67%; top: 33%; position: fixed; background-color: white; font-size:1em; overflow-y: auto; overflow-x: hidden; z-index: 1;}
    </style>    
</head>
<?php 
  include('dbconn.php');
    if (isset($_POST['upload']))
     {
      $topic=$_POST['utopic'];
      $text=$_POST['utext'];
      $st=0;
      $query = "INSERT INTO posttable (Postwriter, WriterName, PostTopic, PostContent, Status) VALUES ('" . $_SESSION['upk'] . "', '" . $_SESSION['uname'] . "', '$topic', '$text', '$st')";

       mysqli_query($db, $query);

    if($query==true){
      echo "<script>alert('Requested to admin');</script>";
    }
    else{
      echo "<script>alert('Failed to request!');</script>";
    }
}
?>


<body class="overflow-x-hidden bg-light">
    <!-- navbar-start -->
    <nav class="navbar navbar-expand-md shadow-sm sticky-top" id="navbar">
        <div class="container-fluid">
          <img src="./image/logo.png" style="width: 60px; height:60px; margin-left: 10px;">
          <span class="logo" href="#">ပညာဝေဆာ "သီရိခေတ္တရာ"</span>
          <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon" id="navbar1" ></span>
          </button>
          <div class="top-nav collapse navbar-collapse bg-white justify-content-end" id="navbarNav">
            
              <div class="form-check form-switch d-inline-block" style="margin-left: 100px;">
                <input type="checkbox" class="form-check-input" id="darkModeSwitch" onclick="openbtn()" onkeydown="closebtn()">
                <label class="form-check-label" for="darkModeSwitch"></label>
              </div>
          </div>
        </div>
      </nav>  
    <!-- navbar-end -->

      <div class="main-left border-end border-info" id="main-left" style="background-color: lightgray;">
        <div class="">
            <div class="left-top">
              <?php
              echo "<h4 style='font-family: sans-serif;'>{$_SESSION['uname']}'s profile</h4>";
              ?>

              <div class='border border-primary'></div>
                  <div class='card mt-4 p-2' aria-hidden='true'>
                    <div class='profilepic'><img src='./image/default-user.png' style="border: 2px solid blue; border-radius: 100%"></div>
                    <div class='card-body'>
              <?php
                echo "<b>Name - </b>".$_SESSION['uname'];
                echo "<br><b>PAKAPATA - </b>".$_SESSION['upk'];
              ?>

              <form method="Post" action="userprofile.php">
                <button class='btn btn-primary btn-sm mt-2 text-light' style='width: 100%;' 
                name="view">View Profile</button>
              </form> 
                      <!-- <a href='userProfile.php'><button class='btn btn-primary btn-sm mt-2 text-light' style='width: 100%;' >View Profile</button></a> -->
                    </div>
                  </div>
                  
                
            </div>
            <div class="border mt-4"></div>

            <div class="left-bottom p-4">
                <h6 class="" style="color: gray;">Activity</h6>
                <a href="home.php"><button class="btn btn-outline-light mt-3 mb-1 text-lg-start text-black"><i class="fa-solid fa-chevron-up fa-rotate-90 me-3" style="color: gray;"></i><i class="fa-solid fa-house me-2 text-primary"></i>Home</button></a><br>
                <button class="btn btn-outline-light mb-1 text-lg-start text-black" type="button" data-bs-toggle="offcanvas" data-bs-target="#offcanvasright"><i class="fa-solid fa-chevron-up fa-rotate-90 me-3" style="color: gray;"></i><i class="fa-solid fa-cloud-arrow-up me-2 text-primary"></i>Upload</button><br>
                <!-- <a href=""><button class="btn btn-outline-light mb-1 text-lg-start text-black position-relative"><i class="fa-solid fa-chevron-up fa-rotate-90 me-3" style="color: gray;"></i><i class="fa-regular fa-bell fa-lg me-2 text-primary"></i>Notification <span class="badge position-absolute mt-1 text-danger rounded-circle text-bg-danger text-light">0</span></button></a><br> -->
                <a href="upload.php"><button class="btn btn-outline-light mb-1 text-lg-start text-black"><i class="fa-solid fa-chevron-up fa-rotate-90 me-3" style="color: gray;"></i><i class="fa-solid fa-circle-left me-2 text-primary"></i>back</button></a>
                <a href="userProfile.php"><button class="btn btn-outline-light mb-1 text-lg-start text-black"><i class="fa-solid fa-chevron-up fa-rotate-90 me-3" style="color: gray;"></i><i class="fa-solid fa-right-from-bracket me-2 text-primary"></i>Log out</button></a>
            </div>
            <div class="border"></div>
        </div>
    </div>

    <div class="main-right" id="main-right">
      <!-- offcanvas-start -->
      <div class="offcanvas offcanvas-end" tabindex="-1" id="offcanvasright">
        <div class="offcanvas-header">
          <div class="offcanvas-title">
            <div class="texttitle p-1 text-muted d-inline-block mt-2">&nbsp;Share your facts with friends.</div>
          </div>
        </div>
        <div class="offcanvas-body">
            <form method="post">
              <div class="offcanvas-container m-auto" style="height: 400px;">
                <div class="ms-5">
                  <input class="form-control" type="text" name="utopic" placeholder="Topic">
                  <input class="form-control" type="text" name="uname" value="<?php echo $_SESSION['uname']; ?>" readonly>
                  <input class="form-control" type="text" name="upakapata" value="<?php echo $_SESSION['upk']; ?>" readonly>
                </div>
                <textarea name="utext" class="txtarea form-control h-75 w-75 ms-5" style="height: 50px; border: 1px solid gray;"></textarea>
                <div class="btn-container btn-group w-75 ms-5 mt-4 mb-5">
                  <button class="btn btn-primary" type="submit" name="upload">Upload</button>
                  <button class="btn btn-primary" type="button" data-bs-dismiss="offcanvas">Cancel</button>
                </div>
              </div>
            </form>
        </div>
      </div>
      <!-- offcanvas-end -->

         <div class="container-fluid">
          <div class="row">
            <!-- posting-area -->
            <div class="col-md-7 mb-5 d-block">

            <!-- bottom-nav -->
              <div class="bot-nav p-0 z-1">
                <div class="">
                  <span class="d-inline-block ms-3 mt-1">
                      <?php
                      // Assuming you already have a database connection in $db

                      $query = "SELECT * FROM userinfo";
                      $result = mysqli_query($db, $query);

                      if ($result) {
                          // Count the number of rows in the result set
                          $rowCount = mysqli_num_rows($result);

                          // Output the row count
                          echo "<h5 class='ms-3 mt-1'>"."{$rowCount} Users"."</h5>";

                          // Rest of your code to process the result set
                          while ($row = mysqli_fetch_assoc($result)) {
                              // Process each row as needed
                              // Example: echo $row['column_name'];
                          }

                          // Free the result set
                          mysqli_free_result($result);
                      } else {
                          // Handle the case where the query fails
                          echo "Query failed: " . mysqli_error($db);
                      }

                      // Close the database connection
                      mysqli_close($db);
                      ?>

                  </span>
                  <div id="dateContainer" class="d-inline-block" style="margin-left: 60%;"></div>
                </div>
              </div>
            <!-- bottom-nav -->

                  <?php
                      include('dbconn.php');
                      $sql = "select * from adminpost";
                      $result1=mysqli_query($db,$sql);

                      if ($result) {
				              	while ($row=mysqli_fetch_assoc($result1)) {
                          $name = $row['Name'];
                          $topic = $row['Topic'];
                          $information = $row['Information'];
                          $date = $row['Date'];

                          echo '
                                <table border=1 class="table w-75 mt-5 mb-5" style="margin-left: 100px">
                                  <tr height=50px>
                                    <td width="10px" class="bg-light"><div class="d-inline-block" style="margin-left: 15px; margin-top: 5px; border-radius: 100%; background-color:gray"><img src="./image/default-user.png" style="width:56px;height:56px;object-fit: fill; border: 2px solid #1fd655; border-radius:100%"></div></td>
                                    <td class="bg-light"><span style="font-size: 18px;"><b>'.$name.'</b></span><i class="fa-solid fa-ellipsis-vertical text-secondary float-end"></i><br><span style="font-size: 14px; color:#00ab41"><b>( <i>'.$topic.'</i> )</b></span><br><span style="font-size: 10px;" class="float-end"><u>'.$date.'</u></span></td>
                                  </tr>
                                  <tr height= 200px>
                                    <td style="overflow-y:auto; padding: 20px;" colspan=2>'.$information.'</td>
                                  </tr>
                                  <tr>
                                  <td colspan=2 align="center">
                                    <button disabled class="btn btn-sm btn-outline-secondary w-25 comment-button" type="button" name="comment" data-bs-toggle="offcanvas" data-bs-target="#offcanvasleft" data-post-id="<?php echo $postId; ?>" data-user-name="<?php echo $userName; ?>" data-user-pk="<?php echo $userPk; ?>">
                                      Write Comment
                                    </button>
                                  </td>
                                  </tr>
                                </table>
                          ';
                        }
                      }
                    ?>
              </div>
              <!-- posting-area -->
              <div class="col-md-5 mb-5">
                <form method="POST">
                  <div id="searchbar" class="">
                    <input type="search" class="border-info rounded-3 text-muted" name="search" id="find" placeholder="&nbsp;&#x1F50DSearch post here!">
                    <input type="submit" class="border-info rounded-3" name="submit" value="Search" style="height:45px;">
                  </div>
                </form>
              </div>
            </div>
        </div>

     </div>
  </div>
</body>
<script src="./js/bootstrap.js"></script>
<script>
  function openbtn(){
      document.getElementById('navbar').style.backgroundColor = "rgba(240,240,240)";
      document.getElementById('navbar1').style.backgroundColor = "rgba(240,240,240)";
      document.getElementById('navbar2').style.backgroundColor = "rgba(240,240,240)";
      document.getElementById('main-left').style.backgroundColor = "rgba(0,0,100,0.4)";
      document.getElementById('main-right').style.backgroundColor = "rgba(0,0,100,0.4)";
      document.body.style.backgroundColor = "rgba(0,0,100,0.4)";
    }
    function closebtn(){
      document.getElementById('navbar').style.backgroundColor = "white";
      document.getElementById('navbar1').style.backgroundColor = "white";
      document.getElementById('navbar2').style.backgroundColor = "white";
      document.getElementById('main-left').style.backgroundColor = "lightgray";
      document.getElementById('main-right').style.backgroundColor = "";
      document.body.style.backgroundColor = "";
    }
</script>
<script>
    // Get the current date
    var today = new Date();
        
    // Format the date as desired
    var formattedDate = today.toLocaleDateString('en-US', { year: 'numeric', month: 'long', day: 'numeric' });
        
    // Get the div element by its ID
    var dateContainer = document.getElementById('dateContainer');
        
    // Update the content of the div with the formatted date
    dateContainer.innerHTML =formattedDate;
</script>
</html>