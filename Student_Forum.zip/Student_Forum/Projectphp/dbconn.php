<?php
    $db = mysqli_connect('localhost','root','','phpproject');
    if($db == true){
      echo "<script> console.log('Database connect successfully.')</script>";
    }
    else{
      die("Error:".mysqli_connect_error($db));
    }
?>
