<?php
  session_start();
  error_reporting(E_ALL);
  ini_set('display_errors', 1); 

	include("dbconn.php");

	if (isset($_POST['submit'])) {
    $searchval = $_POST['search'];

    $query = "SELECT * FROM posttable WHERE Posttopic LIKE '%$searchval%' OR PostWriter LIKE '%$searchval%' OR WriterName LIKE '%$searchval%' OR PostContent LIKE '%$searchval%' ";

    $result = mysqli_query($db, $query);

    if ($result->num_rows > 0) {
        echo '<div id="resultDiv">';
        while ($row = $result->fetch_assoc()) {
            $name = $row['WriterName'];
            $tp = $row['PostTopic'];
            $post = $row['PostContent'];
            $date = $row['PostDate'];
            
          echo '
                <table border=1 class="table w-75 mt-4 mb-3" style="margin-left: 55px">
                  <tr height=50px>
                    <td width="10px" class="bg-light"><div class="d-inline-block" style="margin-left: 15px; margin-top: 5px; border-radius: 100%;"><img src="./image/default-user.png" style="width:56px;height:56px;object-fit: fill; border: 2px solid #1fd655; border-radius:100%"></div></td>
                    <td class="bg-light"><span style="font-size: 17px;"><b>'.$name.'</b></span><i class="fa-solid fa-ellipsis-vertical text-secondary float-end"></i><br><span style="font-size: 14px; color:#00ab41"><b>( <i>'.$tp.'</i> )</b></span><br><span style="font-size: 10px;" class="float-end"><u>'.$date.'</u></span></td>
                  </tr>
                  <tr height= 200px>
                    <td style="overflow-y:auto; padding: 20px;" colspan=2>'.$post.'</td>
                  </tr>
                </table>';
        }
        echo '</div>';
    } else {
        echo '<script>alert("Result not found")</script>';
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="./fontawesome-free-6.4.2-web/css/all.css">
    <link rel="stylesheet" href="./css/bootstrap.css">
    <style>
      .navbar{height: 70px; background-color: white; border-bottom: 1px solid gray; width: auto;}
      .top-nav a{color: black; margin-top: 5px; margin-left: 40px;}

      /* ::-webkit-scrollbar{width: 15px;}
      ::-webkit-scrollbar-thumb{background-color: pink;}
      ::-webkit-scrollbar-track{background-color: #5597dd;} */
      .active{border-bottom: 3px solid blue;}
      .top-nav a:hover{border-bottom: 3px solid blue; width: auto;}

      .bot-nav{width: 100%; position: fixed; bottom: 0; border-top: 2px solid gray; background-color: white; height: 45px; z-index: 1;}

      .logo{font-size: 45px; margin-left: 30px; font-family: 'Courier New', Courier, monospace; color: #5597dd; font-weight: bold; text-shadow: 2px 2px 3px lightgray;}

        .left-top{padding: 25px; height: 370px;}
        .profilepic img{ width: 116px; height: 116px; margin-left: 15px; margin-top: 10px; border-radius: 100%; object-fit:fill;}
        .left-bottom button{width: 300px; font-size: 15px; padding: 10px; border: none; }

        .main-left{height: 800px; overflow-y: auto; overflow-x: hidden; width: 25%; position: fixed; z-index: 2;}
        .main-right{margin-left: 350px;}

        .texttitle{border: 1px solid lightgray; margin-bottom: 20px; border-radius: 20px; height: 35px; width: 340px; margin-left: 10px;}
        .offcanvas-container input{width: 275px; margin-bottom: 10px; border: 1px solid gray;}
        .offcanvas-container select{width: 275px; margin-bottom: 10px; border: 1px solid gray;}
        #find{width:300px; height:45px; margin-top: 4%; z-index: 1;}
        #searchbar{width: 100%; position: fixed; top: 8%; height: 150px; margin-left: 10px;}
        #resultDiv{ width: 30%; height: 330px; position:absolute; border: 2px solid black; border-radius: 5px; left:67%; top: 33%; position: fixed; background-color: white; font-size:1em; overflow-y: auto; overflow-x: hidden; z-index: 1;}
    </style>    
</head>


<body class="overflow-x-hidden bg-light">
    <!-- navbar-start -->
    <nav class="navbar navbar-expand-md shadow-sm sticky-top" id="navbar">
        <div class="container-fluid">
          <img src="./image/logo.png" style="width: 60px; height:60px; margin-left: 50px;">
          <span class="logo" href="#">UCSP</span>
          <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon" id="navbar1" ></span>
          </button>
          <div class="top-nav collapse navbar-collapse bg-white justify-content-end" id="navbarNav">
            <ul class="navbar-nav" id="navbar2">
              <li class="nav-item">
                <a class="nav-link active" aria-current="page" href="#home">Home</a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="#project">About</a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="#portfolio">Help</a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="#contact">Contact</a>
              </li>
            </ul>
              <div class="form-check form-switch d-inline-block" style="margin-left: 100px;">
                <input type="checkbox" class="form-check-input" id="darkModeSwitch" onclick="openbtn()" onkeydown="closebtn()">
                <label class="form-check-label" for="darkModeSwitch"></label>
              </div>
          </div>
        </div>
      </nav>  
    <!-- navbar-end -->

      <div class="main-left border-end border-info" id="main-left" style="background-color: lightgray;">
        <div class="">
            <div class="left-top">
              <?php
              echo "<h4 style='font-family: sans-serif;'>User's profile</h4>";
              ?>

              <div class='border border-primary'></div>
                  <div class='card mt-4 p-2' aria-hidden='true'>
                    <div class='profilepic'><img src='./image/default-user.png' style="border: 2px solid blue; border-radius: 100%"></div>
                    <div class='card-body'>
              <?php
                echo "<b>Name - </b>User Name";
                echo "<br><b>PAKAPATA - </b>User ID";
              ?>

                      
                      <a href='userProfile.php' name='view'><button class='btn btn-primary btn-sm mt-2 text-light' style='width: 100%;' >View Profile</button></a>
                    </div>
                  </div>
                  
                
            </div>
            <div class="border mt-4"></div>

            <div class="left-bottom p-4">
                <h6 class="" style="color: gray;">Activity</h6>
                <a href="home.php"><button class="btn btn-outline-light mt-3 mb-1 text-lg-start text-black"><i class="fa-solid fa-chevron-up fa-rotate-90 me-3" style="color: gray;"></i><i class="fa-solid fa-house me-2 text-primary"></i>Sample</button></a><br>
                <button class="btn btn-outline-light mb-1 text-lg-start text-black" type="button" data-bs-toggle="offcanvas" data-bs-target="#offcanvasright"><i class="fa-solid fa-chevron-up fa-rotate-90 me-3" style="color: gray;"></i><i class="fa-solid fa-cloud-arrow-up me-2 text-primary"></i>Sample</button><br>
                <!-- <a href=""><button class="btn btn-outline-light mb-1 text-lg-start text-black position-relative"><i class="fa-solid fa-chevron-up fa-rotate-90 me-3" style="color: gray;"></i><i class="fa-regular fa-bell fa-lg me-2 text-primary"></i>Notification <span class="badge position-absolute mt-1 text-danger rounded-circle text-bg-danger text-light">0</span></button></a><br> -->
                <a href="announcement.php"><button class="btn btn-outline-light mb-1 text-lg-start text-black"><i class="fa-solid fa-chevron-up fa-rotate-90 me-3" style="color: gray;"></i><i class="fa-solid fa-user me-2 text-primary"></i>Sample</button></a>
                <a href="mylogin.php"><button class="btn btn-outline-light mb-1 text-lg-start text-black"><i class="fa-solid fa-chevron-up fa-rotate-90 me-3" style="color: gray;"></i><i class="fa-solid fa-right-from-bracket me-2 text-primary"></i>Sample</button></a>
            </div>
            <div class="border"></div>
        </div>
    </div>

    <div class="main-right" id="main-right">
      <!-- offcanvas-start -->
      <div class="offcanvas offcanvas-end" tabindex="-1" id="offcanvasright">
        <div class="offcanvas-header">
          <div class="offcanvas-title">
            <div class="texttitle p-1 text-muted d-inline-block mt-2">&nbsp;Share your facts with friends.</div>
          </div>
        </div>
        <div class="offcanvas-body">
            <form method="post">
              <div class="offcanvas-container m-auto" style="height: 400px;">
                <div class="ms-5">
                  <input class="form-control" type="text" name="utopic" placeholder="Topic">
                  <input class="form-control" type="text" name="uname" value="<?php echo $_SESSION['uname']; ?>" readonly>
                  <input class="form-control" type="text" name="upakapata" value="<?php echo $_SESSION['upk']; ?>" readonly>
                </div>
                <textarea name="utext" class="txtarea form-control h-75 w-75 ms-5" style="height: 50px; border: 1px solid gray;"></textarea>
                <div class="btn-container btn-group w-75 ms-5 mt-4 mb-5">
                  <button class="btn btn-primary" type="submit" name="upload">Upload</button>
                  <button class="btn btn-primary" type="button" data-bs-dismiss="offcanvas">Cancel</button>
                </div>
              </div>
            </form>
        </div>
      </div>
      <!-- offcanvas-end -->

         <div class="container-fluid">
          <div class="row">
            <!-- posting-area -->
            <div class="col-md-7 mb-5 d-block">

            <!-- bottom-nav -->
              <div class="bot-nav p-0 z-1">
                <div class="">
                  <span class="d-inline-block ms-3 mt-1">
                      <?php
                      // Assuming you already have a database connection in $db

                      $query = "SELECT * FROM userinfo";
                      $result = mysqli_query($db, $query);

                      if ($result) {
                          // Count the number of rows in the result set
                          $rowCount = mysqli_num_rows($result);

                          // Output the row count
                          echo "<h5 class='ms-3 mt-1'>"."{$rowCount} Users"."</h5>";

                          // Rest of your code to process the result set
                          while ($row = mysqli_fetch_assoc($result)) {
                              // Process each row as needed
                              // Example: echo $row['column_name'];
                          }

                          // Free the result set
                          mysqli_free_result($result);
                      } else {
                          // Handle the case where the query fails
                          echo "Query failed: " . mysqli_error($db);
                      }

                      // Close the database connection
                      mysqli_close($db);
                      ?>

                  </span>
				  <a href="postcontroladmin.php" style="margin-left: 360px; margin-bottom: 5px" class="btn btn-sm btn-outline-primary">Back to manipulation</a>
                  <div id="dateContainer" class="d-inline-block" style="margin-left: 25%;"></div>
                </div>
              </div>
            <!-- bottom-nav -->

                  <?php
                      include('dbconn.php');
                      	$query="SELECT * FROM posttable WHERE Status = 1";
					  	$result = mysqli_query($db, $query);

						  $sql = "select * from adminpost";
						  $result1=mysqli_query($db,$sql);
	
						  if ($result) {
							while ($row=mysqli_fetch_assoc($result1)) {
							  $name = $row['Name'];
							  $topic = $row['Topic'];
							  $information = $row['Information'];
							  $date = $row['Date'];
	
							  echo '
									<table border=1 class="table w-75 mt-5 mb-5" style="margin-left: 100px">
									  <tr height=50px>
										<td width="10px" class="bg-light"><div class="d-inline-block" style="margin-left: 15px; margin-top: 5px; border-radius: 100%; background-color:gray"><img src="./image/default-user.png" style="width:56px;height:56px;object-fit: fill; border: 2px solid #1fd655; border-radius:100%"></div></td>
										<td class="bg-light"><span style="font-size: 18px;"><b>'.$name.'</b></span><i class="fa-solid fa-ellipsis-vertical text-secondary float-end"></i><br><span style="font-size: 14px; color:#00ab41"><b>( <i>'.$topic.'</i> )</b></span><br><span style="font-size: 10px;" class="float-end"><u>'.$date.'</u></span></td>
									  </tr>
									  <tr height= 200px>
										<td style="overflow-y:auto; padding: 20px;" colspan=2>'.$information.'</td>
									  </tr>
									  <tr>
									  <td colspan=2 align="center">
										<button class="btn btn-sm btn-outline-primary w-25" type="button" name="comment">Comment</button>
										<button class="btn btn-sm btn-outline-primary w-25" type="button" name="comment"><a>Save</a></button>
									  </td>
									  </tr>
									</table>
							  ';
							}
						  }

                      
				              if ($result) {
				              	while ($row=mysqli_fetch_assoc($result)) {
				              		$id=$row['PostId'];
				              		$wid=$row['Postwriter'];
                          			$name=$row['WriterName'];
				              		$tp=$row['PostTopic'];
				              		$post=$row['PostContent'];
				              		$date=$row['PostDate'];
				              		$st=$row['Status'];
                          			$_SESSION['pid'] =$id;

                          echo '
                                <table border=1 class="table w-75 mt-5 mb-5" style="margin-left: 100px">
                                  <tr height=50px>
                                    <td width="10px" class="bg-light"><div class="d-inline-block" style="margin-left: 15px; margin-top: 5px; border-radius: 100%;"><img src="./image/default-user.png" style="width:56px;height:56px;object-fit: fill; border: 2px solid #1fd655; border-radius:100%"></div></td>
                                    <td class="bg-light"><span style="font-size: 18px;"><b>'.$name.'</b></span><i class="fa-solid fa-ellipsis-vertical text-secondary float-end"></i><br><span style="font-size: 14px; color:#00ab41"><b>( <i>'.$tp.'</i> )</b></span><br><span style="font-size: 12px;" class="float-end"><u>'.$date.'</u></span></td>
                                  </tr>
                                  <tr height= 200px>
                                    <td style="overflow-y:auto; padding: 20px;" colspan=2>'.$post.'</td>
                                  </tr>
                                  <tr>
                                    <td colspan=2>
                                    <button class="btn btn-sm btn-outline-primary w-25" data-bs-toggle="modal" data-bs-target="#staticBackdrop" type="button" name="comment">Comment</button>
                                    </td>
                                                            
                                    
                                  </tr>
                                </table>';
                          }
                        }
                          
                    ?>
              </div>
              <!-- Modal -->
              <?php
                //commentsection
                if (isset($_POST['com'])) {
                  $ccontent = $_POST['cbox'];
                  $cdate = date('Y-m-d H:i:s');
                  $query = "INSERT INTO commenttable (PostId,CName, CPakapata, CContent, CDate) VALUES ('" . $_SESSION['pid'] . "','" . $_SESSION['uname'] . "','" . $_SESSION['upk'] . "','$ccontent','$cdate') ";
                  $result = mysqli_query($db, $query);
                  if ($result) {
                    echo 'Commenter name: ' . $_SESSION['uname'];
                    header('location:showcomment.php');
                  } else {
                    echo 'Comment is not set';
                  }
              }
              ?>
              <div class="modal fade" id="staticBackdrop" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
                <div class="modal-dialog modal-dialog-centered modal-dialog-scrollable">
                  <div class="modal-content">
                    <div class="modal-header">
                      <h1 class="modal-title fs-5" id="staticBackdropLabel">Comment here!</h1>
                      <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body">
                          
                          <form action="showcomment.php" method="POST">
                          <div class="form-group">
                            <label for="postid">PostId</label>
                            <input type="text" class="form-control" name="posting" value="<?php echo $_SESSION["pid"]; ?>" readonly>
                          </div>
                  
                          <div class="form-group">
                            <label for="uname">Username</label>
                            <input type="text" class="form-control" name="uname" value="<?php echo $_SESSION["uname"]; ?>" readonly>
                          </div>
                          <div class="form-group">
                            <label for="upakapata">User Pakapata</label>
                            <input type="text" class="form-control" name="upakapata" value="<?php echo $_SESSION["upk"]; ?>" readonly>
                          </div>
                          <div class="form-group">
                            <label for="cbox">Comment</label>
                            <input type="text" class="form-control" id="cbox" name="cbox">
                          </div>
                          </form>
                          
                    </div>
                    <div class="modal-footer">
                      <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                      <button type="submit" class="btn btn-primary" name="com">Submit</button>
                    </div>
                  </div>
                </div>
              </div>

              <!-- posting-area -->
              <div class="col-md-5 mb-5">
                <form method="POST">
                  <div id="searchbar" class="">
                    <input type="search" class="border-info rounded-3 text-muted" name="search" id="find" placeholder="&nbsp;&#x1F50DSearch post here!">
                    <input type="submit" class="border-info rounded-3" name="submit" value="Search" style="height:45px;">
                  </div>
                </form>
              </div>
            </div>
        </div>

     </div>
  </div>
</body>
<script src="./js/bootstrap.js"></script>
<script>
  function openbtn(){
      document.getElementById('navbar').style.backgroundColor = "rgba(240,240,240)";
      document.getElementById('navbar1').style.backgroundColor = "rgba(240,240,240)";
      document.getElementById('navbar2').style.backgroundColor = "rgba(240,240,240)";
      document.getElementById('main-left').style.backgroundColor = "rgba(0,0,100,0.4)";
      document.getElementById('main-right').style.backgroundColor = "rgba(0,0,100,0.4)";
      document.body.style.backgroundColor = "rgba(0,0,100,0.4)";
    }
    function closebtn(){
      document.getElementById('navbar').style.backgroundColor = "white";
      document.getElementById('navbar1').style.backgroundColor = "white";
      document.getElementById('navbar2').style.backgroundColor = "white";
      document.getElementById('main-left').style.backgroundColor = "lightgray";
      document.getElementById('main-right').style.backgroundColor = "";
      document.body.style.backgroundColor = "";
    }
</script>
<script>
    // Get the current date
    var today = new Date();
        
    // Format the date as desired
    var formattedDate = today.toLocaleDateString('en-US', { year: 'numeric', month: 'long', day: 'numeric' });
        
    // Get the div element by its ID
    var dateContainer = document.getElementById('dateContainer');
        
    // Update the content of the div with the formatted date
    dateContainer.innerHTML =formattedDate;
</script>
</html>