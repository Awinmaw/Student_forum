<?php
session_start();
error_reporting(E_ALL);
ini_set('display_errors', 1);

include('dbconn.php');

if (isset($_POST['submit'])) {
    $em = $_POST['iee'];
    $pw = $_POST['ipp'];
    $id = $_POST['idd'];

    $query = "SELECT UName,UPakapata,UYear,UEmail,UPassword FROM userinfo WHERE UEmail='$em' AND UPakapata='$id' AND UPassword='$pw'";
    $result = mysqli_query($db, $query);

    if ($result) {
        $row_count = mysqli_num_rows($result);

        if ($row_count > 0) {
            $row = mysqli_fetch_assoc($result);
            $_SESSION['uname'] = $row['UName'];
            $_SESSION['upk'] = $row['UPakapata'];
            $_SESSION['uyr'] = $row['UYear'];
            $_SESSION['uem'] = $row['UEmail'];
            header('Location: upload.php?Loginsuccessful');
            exit();
        } else {
            echo '<script>alert("Invalid Information");</script>';
            header('Location: loginfail.php');
            exit();
        }
    } else {
        echo '<script>alert("Admin not found");</script>';
        header('Location: infoalert.php?adminisnotfound');
        exit();
    }
}
?>

 <!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title></title>
	<link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
	<link rel="stylesheet" href="./css/bootstrap.css">
	<link rel="stylesheet" href="./fontawesome-free-6.4.2-web/css/all.min.css">
	<link rel="stylesheet" type="text/css" href="footer.css">
	<style type="text/css">
		body{
			width:100%;
			height:100%;
		}
		#d1{
			background:linear-gradient(#22668D,#8ECDDD);
			width:45%;
			left:27%;
			height:670px;
			top:20%;
			position:absolute;
			border-radius: 50px;
			border:1px solid navy;
			box-shadow: 2px 2px 3px lightgray;
			font-family: cursive;
		}
		tr{
			margin-bottom: 30px;
		}
		*{
            padding:0;
            margin:0;
        }
        body{
            background-image: url('./image/bg.jpg');
            width:100%;
            height:100%;
            background-attachment:fixed;
            background-position: center center;
            background-size:cover;
        }
        .let{
            width:60%;
            height:100%;
            margin-left:20%;
            margin-top:200px;
            color:#5651e1;
            text-align:center;
        }
        .aa{
            margin-left:43%;
            margin-top:70px;
        }
        .ll{
        	display:block;
        	margin-bottom:20px;
        	width:200px;
        	height:35px;
        	border-radius:10px;
        	border:2px solid ghostwhite;
        	color:white;
        	background-color:transparent;
        }
		h1{color: rgb(178, 178, 231)}
	</style>
</head>
<body class="bg-light">

	 <nav class="navbar navbar-expand-lg bg-body-tertiary">
		<div class="container-fluid">
			<img src="./image/logo.png" alt="" width="70px">
		   <h3 style="margin-left:100px;">ပညာဝေဆာ "သီရိခေတ္တရာ"</h3>
			<div class="btn-group slogin">
				<a href="home.php" class="btn btn-success active" aria-current="page">Home</a>
				<a href="register.php" class="btn btn-outline-primary">Sign Up</a>
				<a href="mylogin.php" class="btn btn-outline-success">Login</a>
			  </div>

		  </div>
		</div>
	  </nav>
	<div id="d1">
		<center><h2 class="mt-3 fw-bold text-white ">Student Login</h2></center>
		<img src="./image/programmer.jpg" width="150px" class="rounded-4" style="position:absolute;left:39%;top:14%; border:1px solid gray">
		<form style="position:absolute;top:45%; left: 25%"  method="POST">
				
				<label class="float-start text-white-50">PAKAPATA</label>
				<input type="text" name="idd" placeholder="Enter Your Student ID" class="ll form-control w-100">
				<label class="float-start text-white-50">Email</label>
				<input type="text" name="iee" placeholder="Enter Your Email" class="ll form-control w-100">
				<label class="float-start text-white-50">Password</label>
				<input type="password" name="ipp" maxlength="15" placeholder="Enter Your Password" class="ll form-control w-100">
			
			<div>
				<input class="btn w-100 mb-2 mt-1" style="background-color: #22668D; color:white" type="submit" name="submit" value="Login">
				<input class="btn w-100 mb-2" style="background-color: #22668D; color:white" type="reset" name="reset" value="Cancel" style="margin-right:100px;">
			</div>
		</form>
	</div>
	<div class="container-fluid bg-white" id="foot" style="position:absolute;top:120%;width:100%;">
		<div class="row pt-2" style="border-top:2px solid #22668D;">
		<div class="col-sm-4" id="left" align="center">
			<h1>Contact</h1>
			<div class="l1">
				 <label><a href="mailto:winpapaminn@gmail.com"><i class="fa-solid fa-envelope-open-text fa-2xl text-primary mt-4 mb-3"></i></a></label>
			</div>
			<div class="l2">
				 <label><a href="tel:+959660113312"><i class="fa-solid fa-square-phone fa-2xl mb-3" style="color: #38ee2b;"></i></i></a></label>
				
			</div>
			<div class="l3">
				<label><a href=""><i class="fa-brands fa-square-facebook fa-2xl text-primary mb-3"></i></a></label>
			</div>
			<div class="l4">
				 <label><a href=""><i class="fa-brands fa-instagram fa-2xl text" style="color: #de1b1b;"></i></a></label>
			</div>
			
		</div>
		<div class="col-sm-4" id="mid" align="center">
			<h1>Go To</h1>
			<a href="">Home</a>
			<a href="">Feed</a>
			<a href="">Profile</a>
			<a href="">Contact Us</a>
			<a href="">Support Us</a>
			<a href="">Get Help and Support</a>
		</div>
		<div class="col-sm-4" id="right" align="center">
			<h1>Support Team<a href="" ><img src="./image/coding.png" width="50px"></a> </h1>
			<a href="mailto:hmuekhantpaing@gmail.com">Khant Hmu Paing</a>
			<a href="mailto:mawkoonhein.nov2002@gmail.com">Maw Koon Hein</a>
			<a href="mailto:winpapamin@gmail.com">Win Pa Pa Min</a>
			<a href="mailto:papa.tp.2020@gmail.com">Pa Pa Win Thwin</a>
		</div>
	</div>
	<div class="row text-white" style="background-color:#22668D;height:60px;">
			<div class="col-12" align="center">
				  <a href="https://www.google.com/maps?q=18.8229,95.2556"><img src="./image/placeholder.png" class="mt-2" width="45px" height="45px"></a><label>Pyay-Aung Lan Main Road, Pyay Wetern</label>
			</div>
	</div>
	<div class="row">
		<div class="col-12 pt-1" align="center" style="background-color:powderblue;height:45px;">
			<h3>&copy 2024 UCSP, this forum is for school.</h3>
		</div>
	</div>
	</div>
</body>
	<script type="text/javascript" src="js/bootstrap.min.js"></script>
</html>