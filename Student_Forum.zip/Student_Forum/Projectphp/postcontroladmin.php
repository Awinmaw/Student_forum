<!DOCTYPE html>
<?php 
session_start();
include("dbconn.php");
if (isset($_POST['submit'])) {
    $searchval = $_POST['se'];

    $query = "SELECT * FROM posttable WHERE PostId LIKE '%$searchval%' OR Postwriter LIKE '%$searchval%' OR PostTopic LIKE '%$searchval%' OR PostContent LIKE '%$searchval%' OR PostDate LIKE '%$searchval'";

    $result = mysqli_query($db, $query);

    if ($result->num_rows > 0) {
        echo '<div id="resultDiv">';
        echo '<table class="table table-striped" style="font-size:14px">
                <tr align="center">
                  <th>ID</th>
                  <th>Writer</th>
                  <th>Topic</th>
                  <th>Content</th>
                  <th>PostDate</th>
                </tr>';
        while ($row = $result->fetch_assoc()) {
            echo '<tr align="center">
            		    <td>'.$row['PostId'].'</td>
                    <td>'.$row['Postwriter'].'</td>
                    <td class="text-success">'.$row['PostTopic'].'</td>
                    <td class="text-primary">'.$row['PostContent'].'</td>
                    <td>'.$row['PostDate'].'</td>
                    
                </tr>';
        }
        echo '</table></div>';
    } else {
        echo '<script>alert("Result not found")</script>';
    }
}
?>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="./fontawesome-free-6.4.2-web/css/all.css">
    <link rel="stylesheet" href="./css/bootstrap.css">
    <style>
      .navbar{height: 70px; background-color: white; border-bottom: 1px solid gray; width: auto;}
      .top-nav a{color: black; margin-top: 5px; margin-left: 40px;}

      /* ::-webkit-scrollbar{width: 15px;}
      ::-webkit-scrollbar-thumb{background-color: pink;}
      ::-webkit-scrollbar-track{background-color: #5597dd;} */
      /* .active{border-bottom: 3px solid blue;} */
      .active{border-bottom: 3px solid blue;}
      .top-nav a:hover{border-bottom: 3px solid blue; }

      .bot-nav{width: 100%; position: fixed; bottom: 0; border-top: 2px solid gray; background-color: white; height: 40px; overflow: hidden;}

      .logo{font-size: 25px; margin-left: 550px; text-shadow: 2px 2px 3px lightgray;}
        .left-top{padding: 20px; height: 370px;}
        .profilepic img{width: 110px; height: 110px; object-fit: cover; margin-top: 10px; margin-left: 15px;}
        .left-bottom button{width: 300px; font-size: 15px; padding: 10px; border: none;}

        .main-left{height: 840px; overflow-y: auto; overflow-x: hidden; width: 24%; position: fixed; z-index: 2;}
        .main-right{margin-left: 350px;}
        .post-container{width: 90%; height: 600px;}
        .texttitle{border: 1px solid darkgrey; margin-bottom: 20px; border-radius: 20px; height: 35px; width: 300px; margin-left: 190px;}
        .post-container input{width: 250px; margin: 5px;}
        .post-container select{width: 250px; margin: 5px;}
        th{font-size: 18px; font-family: 'Courier New', Courier, monospace;}
        table{font-family: Arial, Helvetica, sans-serif; font-size: 15px;}
        #find{width:300px; height:45px; margin-left: 25%; margin-top: 4%; z-index: 1;}
        #searchbar{width: 100%; margin-left: 3px; border-bottom: 1px solid lightgray; position: fixed; top: 5%; height: 250px; background-color: white; z-index: 5;}
        #resultDiv{ width: 56%; height: 120px; position:absolute; border-bottom-left-radius: 10px; left:35%; position: fixed; background-color: white; top: 19%; font-size:1em; overflow-y: auto; z-index: 10;}
    </style>
</head>
<body class="overflow-x-hidden">
    <!-- navbar-start -->
    <nav class="navbar navbar-expand-md shadow-sm sticky-top" id="navbar">
        <div class="container-fluid">
          <img src="./image/logo.png" style="width: 60px; height:60px; margin-left: 10px;">
          <span class="logo" href="#">ပညာဝေဆာ "သီရိခေတ္တရာ"</span>
          <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon" id="navbar1" ></span>
          </button>
          <div class="top-nav collapse navbar-collapse bg-white justify-content-end" id="navbarNav">
              <div class="form-check form-switch d-inline-block" style="margin-left: 100px;">
                <input type="checkbox" class="form-check-input" id="darkModeSwitch" onclick="openbtn()" onkeydown="closebtn()">
                <label class="form-check-label" for="darkModeSwitch"></label>
              </div>
          </div>
        </div>
      </nav>    
    <!-- navbar-end -->

      <div class="main-left border-end border-info" id="main-left" style="background-color: lightgray;">
        <div class="">
            <div class="left-top">
              <?php
                echo "<h4 style='font-family: sans-serif;'>{$_SESSION['name']}'s profile</h4>";
              ?>
                  
                <div class="border border-primary"></div>
                  
                  <div class="card mt-4 mb-2 p-2" aria-hidden="true">
                    <div class="profilepic"><img src="./image/default-user.png" style="border: 2px solid blue; border-radius: 100%"></div>

                    <div class="card-body">
                    <?php
                      echo "<b>Name - </b>".$_SESSION['name'];
                      echo "<br><b>Email - </b><span class='text-primary'>".$_SESSION['email']."</span>";
                    ?>
                      <!-- <h5 class="card-title placeholder-glow">
                        <span class="placeholder col-5"></span>
                      </h5>
                      <p class="placeholder-glow">
                        <span class="placeholder col-7"></span>
                        <span class="placeholder col-4"></span>
                        <span class="placeholder col-4"></span>
                        <span class="placeholder col-6"></span>
                        <span class="placeholder col-8"></span>
                      </p> -->
                      <a href="adminprofile.php" name="view"><button class="btn btn-primary btn-sm mt-4 text-light w-100">View Profile</button></a>
                    </div>
                    
                  </div>
            </div>
            <div class="border mt-5"></div>

            <div class="left-bottom p-4">
                <h6 class="" style="color: gray;">Activity</h6>
                <a href="home.php"><button class="btn btn-outline-light mt-3 mb-1 text-lg-start text-black"><i class="fa-solid fa-chevron-up fa-rotate-90 me-3" style="color: gray;"></i><i class="fa-solid fa-house me-2 text-primary"></i>Home</button></a><br>
                <a href="acccontroladmin.php"><button class="btn btn-outline-light mb-1 text-lg-start text-black"><i class="fa-solid fa-chevron-up fa-rotate-90 me-3" style="color: gray;"></i><i class="fa-solid fa-bars-progress text-primary me-2"></i>Manipulate Account</button></a><br>
                <!-- <a href=""><button class="btn btn-outline-light mb-1 text-lg-start text-black position-relative"><i class="fa-solid fa-chevron-up fa-rotate-90 me-3" style="color: gray;"></i><i class="fa-regular fa-bell fa-lg me-2 text-primary"></i>Notification <span class="badge position-absolute mt-1 text-danger rounded-circle text-bg-danger text-light">0</span></button></a><br> -->
                <!-- <a href="upload.php"><button class="btn btn-outline-light mb-1 text-lg-start text-black"><i class="fa-solid fa-chevron-up fa-rotate-90 me-3" style="color: gray;"></i><i class="fa-solid fa-cloud-arrow-down me-2 text-primary"></i>Newfeed</button></a> -->
                <a href="adminlogin.php"><button class="btn btn-outline-light mb-1 text-lg-start text-black"><i class="fa-solid fa-chevron-up fa-rotate-90 me-3" style="color: gray;"></i><i class="fa-solid fa-right-from-bracket me-2 text-primary"></i>log out</button></a>
            </div>
            
            <div class="border"></div>
            <center><h4  class="mt-5">Posts Manipulation <i class="fa-solid fa-chevron-up fa-rotate-90 me-3" style="color: gray;"></i></h4></center>
</div>
    </div>

    <div class="main-right pt-5" id="main-right">
       <div class="container-fluid">
        <div class="row">
          <div class="col-md-12 col-md-6 mb-5">
            <form method="POST">
              <div id="searchbar" class="">
                <input type="search" class="border-info rounded-3 text-muted" name="se" id="find" placeholder="&#x1F50DSearch..">
                <input type="submit" class="border-info rounded-3" name="submit" value="Search" style="height:45px;">
              </div>
            </form>

            <div class="bot-nav p-0 z-1">
              <div class="">
                <span class="d-inline-block ms-4 mt-1">
                <?php
                      // Assuming you already have a database connection in $db

                      $query = "SELECT * FROM userinfo";
                      $result = mysqli_query($db, $query);

                      if ($result) {
                          // Count the number of rows in the result set
                          $rowCount = mysqli_num_rows($result);

                          // Output the row count
                          echo "<h5>"."{$rowCount} Users"."</h5>";

                          // Rest of your code to process the result set
                          while ($row = mysqli_fetch_assoc($result)) {
                              // Process each row as needed
                              // Example: echo $row['column_name'];
                          }

                          // Free the result set
                          mysqli_free_result($result);
                      } else {
                          // Handle the case where the query fails
                          echo "Query failed: " . mysqli_error($db);
                      }

                      // Close the database connection
                      mysqli_close($db);
                      ?>
                </span>
                <a href="adminview.php" style="margin-left: 360px; margin-bottom:2px;" class="btn btn-sm btn-outline-primary">View User Newfeed</a>
                <div id="dateContainer" class="d-inline-block" style="margin-left: 390px;"></div>
              </div>
            </div>
                          
            <form method="POST">
		          <table class="table table-bordered table-striped w-100 table-striped ms-2" id="table" style="margin-top: 15%;">
		          	<tr height="30px" class="table-info p-2" align="center">
		          		<th>ID</th>
		          		<th>Writer Id</th>
		          		<th>Topic Title</th>
		          		<th>Content</th>
		          		<th>Posting Date</th>
		          		<th>Status</th>
		          		<th width="180px">AdminControl</th>
		          	</tr>
		             	<?php 
		             		include("dbconn.php");
		             		$query="select* from posttable";
		             		$result=mysqli_query($db,$query);
		             		if ($result) {
		             			while ($row=mysqli_fetch_assoc($result)) {
		             				$id=$row['PostId'];
		             				$wid=$row['Postwriter'];
		             				$tp=$row['PostTopic'];
		             				$post=$row['PostContent'];
		             				$date=$row['PostDate'];
		             				$st=$row['Status'];
		             				echo '<tr>'.
		             				'<td align="center">'.$id.'</td>'.
		             				'<td align="center">'.$wid.'</td>'.
		             				'<td class="text-success" align="center">'.$tp.'</td>'.
		             				'<td class="text-primary">'.$post.'</td>'.
		             				'<td align="center">'.$date.'</td>'.
		             				'<td align="center">'.$st.'</td>'.
		             				'<td align="center" class="border-0 ms-1 mt-2">
                      <span class="d-flex">
                        <button class="btn btn-sm m-auto btn-outline-info"><a style="text-decoration:none; color:black" href="approve.php?apprId='.$id.'">Approve<i class="fa-regular fa-square-check ms-1" style="color: green;"></i></a></button>
                        <button class="btn btn-sm m-auto btn-outline-info"><a style="text-decoration:none; color:black;" href="rejectpost.php?delId='.$id.'">Reject<i class="fa-solid fa-square-minus ms-1" style="color: #f50535;"></i></a></button>
                      </span>
                    </td>
                </tr>';
		             			}
		             		}
	              ?>
	          	</table>
	          </form>

            </div>
          </div>
          
      </div>
       </div>
    </div>
</body>
<script src="./js/bootstrap.js"></script>
<script>
  function openbtn(){
      document.getElementById('table').style.backgroundColor = "rgba(0,0,100,0.4)";
      document.getElementById('main-left').style.backgroundColor = "rgba(0,0,100,0.4)";
      document.getElementById('main-right').style.backgroundColor = "rgba(0,0,100,0.4)";
      document.body.style.backgroundColor = "rgba(0,0,100,0.4)";
    }
    function closebtn(){
      document.getElementById('main-left').style.backgroundColor = "";
      document.getElementById('main-right').style.backgroundColor = "";
      document.body.style.backgroundColor = "";
    }
</script>
<script>
    // Get the current date
    var today = new Date();
        
    // Format the date as desired
    var formattedDate = today.toLocaleDateString('en-US', { year: 'numeric', month: 'long', day: 'numeric' });
        
    // Get the div element by its ID
    var dateContainer = document.getElementById('dateContainer');
        
    // Update the content of the div with the formatted date
    dateContainer.innerHTML =formattedDate;
</script>
</html>