
  <?php
  session_start();
  error_reporting(E_ALL);
  ini_set('display_errors', 1); 
 ?>
 <?php 
      include('dbconn.php');
     $query = "SELECT * FROM commenttable WHERE PostId = '" . $_SESSION['pid'] . "' AND CPakapata= '". $_SESSION['upk']."'";
     $result=mysqli_query($db,$query);
     if ($result) {
        while ($row=mysqli_fetch_assoc($result)) {
          echo 'Comment Person : '.$row['CName'].'<br>';
          echo 'Commentter Id : '.$row['CPakapata'].'<br>';
          echo 'Comment : '.$row['CContent'].'<br>';
        }
     }
  ?>