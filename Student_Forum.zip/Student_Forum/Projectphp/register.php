<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title></title>
	<link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
	<link rel="stylesheet" href="./fontawesome-free-6.4.2-web/css/all.min.css">
	<link rel="stylesheet" type="text/css" href="footer.css">
</head>
<style type="text/css">
	body{
		width: 100%;
		height:100%;
	}
	.img1{
		width:850px;
		height: 550px;
		border: 2px solid lightgray;
		border-radius: 20px;
		background-repeat:no-repeat;
		position: absolute;
		left:22%;
		top:30%;
		display:block;
	}
	#ff{
		width:350px;
		height: 500px;
		background-color:transparent;
		top:30%;
		left:55%;
		position:absolute;
		color: black;
		display: none;
	}
	#info{
		display:block;
		padding:7px;
		margin-bottom:10px;
		width:200px;
		height:40px;
		background-color:transparent;
		border-color: lightblue;
		cursor: pointer;
		border-radius:8px;
		margin-left:50px;
		color:black;
	}
	/* #cancel{
		margin-top:20px;
	} */

	.p1{
		position:absolute;
		top:30%;
		left:10%;
		text-transform:uppercase;
		font-size:1.2em;
		color:white;
	}
	.h{
		position:absolute;
		top:40%;
		left:5%;
		font-size:1.5em;
		color:forestgreen;
	}
	#signup{
		position: absolute;
		padding:10px;
		top:56%;
		left:15%;
		transition: 1s ease;
		border:2px soild gold;
		border-radius: 10px;
		font-weight: bold;
	}
	#signup:hover{
		border-color:navy;
		transition: .5s;

	}
	#fo1{
		font-size:1.5em;
		text-transform:full-size-kana;
		position: absolute;
		left:50px;
		top:5%;
		}
	#fo{
		position:absolute;
		top:22%;
		margin-top:10px;
	}
	#cancel,#reg,#lg,#liveToastBtn{
		background-color:white;
		color:navy;
		border:1px solid black;
		
	}

	#cancel:hover,#reg:hover,#lg:hover,#liveToastBtn:hover{
		color:black;
		background-color:whitesmoke;

	}
	*{
            padding:0;
            margin:0;
        }
        body{
            background-image: url('./image/bg.jpg');
            width:100%;
            height:100%;
            background-attachment:fixed;
            background-position: center center;
            background-size:cover;
        }
        .let{
            width:60%;
            height:100%;
            margin-left:20%;
            margin-top:200px;
            color:#5651e1;
            text-align:center;
        }
        .aa{
            margin-left:43%;
            margin-top:70px;
        }
		h1{color: rgb(178, 178, 231)}
</style>
<body>
<?php
        include("dbconn.php");
        if (isset($_POST['submit'])){
            $uPakapata = $_POST['upakapata'];
            $uName = $_POST['uname'];
            $uYear = $_POST['uyear'];
            $uEmail = $_POST['uemail'];
            $uPassword = $_POST['upw'];
            $uCPasword = $_POST['ucpw'];

            $query = ("insert into userinfo(UName, UPakapata, UYear, UEmail, UPassword) values ('$uName','$uPakapata', '$uYear', '$uEmail', '$uPassword')");

            mysqli_query($db,$query);

			if($query){
				header('location:mylogin.php');
			}
			else{
				header('location:register.php');
			}
        }
?>
	 <nav class="navbar navbar-expand-lg bg-body-tertiary">
		<div class="container-fluid">
			<img src="./image/logo.png" alt="" width="70px">
		   <h3 style="margin-left:100px;">ပညာဝေဆာ "သီရိခေတ္တရာ"</h3>
			<div class="btn-group slogin">
				<a href="home.php" class="btn btn-success active" aria-current="page">Home</a>
				<a href="register.php" class="btn btn-outline-primary">Sign Up</a>
				<a href="mylogin.php" class="btn btn-outline-success">Login</a>
			  </div>

		  </div>
		</div>
	  </nav>
	<div class="img1">
		<p class="p1">Join and have fun in</p>
		<h1 class="h">UCSPyay Student Forum</h1>
		<input type="button" class="btn btn-outline-success" id="signup" value="Start Your Journey" onclick="showform()">
	</div>
	<div id="ff">
		<p id="fo1">Form to Join Our virtual Community</p>
		<form id="fo" class="mt-3" method="POST">
			<input class="text-black" type="text" name="upakapata" placeholder="Student ID:" id="info">
			<input class="text-black" type="text" name="uname" placeholder="Your Name:" id="info">
			<input class="text-black" type="text" name="uyear" placeholder="Academic Year" id="info">
			<input class="text-black" type="email" name="uemail" placeholder="Your Email:" id="info">
			<input class="text-black" type="password" name="upw" placeholder="Create Password" id="info">
			<input class="text-black" type="password" name="ucpw" placeholder="Confirm Your Password:" id="info">
			<div class="ms-4 mt-4">
				<a href="mylogin.php"><button class="btn" type="button" name="mylogin" id="lg" >LoginHere</button></a>
				<button class="btn" type="reset" name="reset" id="cancel">Reset</button>
				<button class="btn" type="submit" name="submit" id="reg">Create</button>
			</div>
			
		</form>

	</div>
	<div class="container-fluid bg-0" id="foot" style="position:absolute;top:130%;width:100%;">
		<div class="row bg-light" style="border-top:2px solid #22668D;">

			<div class="col-sm-4" id="left" align="center">
				<h1>Contact</h1>
				<div class="l1">
					<label><a href="mailto:winpapaminn@gmail.com"><i class="fa-solid fa-envelope-open-text fa-2xl text-primary"></i></a></label>
				</div>
				<div class="l2">
					 <label><a href="tel:+959660113312"><i class="fa-solid fa-square-phone fa-2xl" style="color: #38ee2b;"></i></i></a></label>

				</div>
				<div class="l3">
					<label><a href=""><i class="fa-brands fa-square-facebook fa-2xl text-primary"></i></a></label>
				</div>
				<div class="l4">
					 <label><a href=""><i class="fa-brands fa-instagram fa-2xl text" style="color: #de1b1b;"></i></a></label>
				</div>
			</div>

		<div class="col-sm-4" id="mid" align="center">
			<h1>Go To</h1>
			<a href="">Home</a>
			<a href="">Feed</a>
			<a href="">Profile</a>
			<a href="">Contact Us</a>
			<a href="">Support Us</a>
			<a href="">Get Help and Support</a>
		</div>
		<div class="col-sm-4" id="right" align="center">
			<h1>Support Team<a href="" ><img src="./image/coding.png" width="50px"></a> </h1>
			<a href="mailto:khanthmupaing@gmail.com">Khant Hmu Paing</a>
			<a href="mailto:mawkoonhain@gmail.com">Maw Koon Hein</a>
			<a href="mailto:winpapamin@gmail.com">Win Pa Pa Min</a>
			<a href="mailto:papawinthwin@gmail.com">Pa Pa Win Thwin</a>
		</div>
	</div>
	<div class="row text-white" style="background-color:#22668D;height:60px;">
			<div class="col-12" align="center">
				  <a href="https://www.google.com/maps?q=18.8229,95.2556"><img src="./image/placeholder.png" class="mt-2" width="45px" height="45px" class="mt-1"></a><label>Pyay Aung Lan Main Road, Pyay Wetern</label>
			</div>
	</div>
	<div class="row">
		<div class="col-12 pt-1" align="center" style="background-color:powderblue;height:45px;">
			<h3 class="cp">&copy 2024 ucspyay, this forum is for school.</h3>
		</div>
	</div>
	</div>
	<script type="text/javascript">
		function showform()
		{	
			var sdiv=document.getElementById("ff");
			sdiv.style.display="block";
			var d=document.getElementById('signup');
			d.style.display="none";
			var a=document.getElementByClassName('img1');
			a.style.display="none";
		}
	</script>
</body>
<script type="text/javascript" src="js/bootstrap.min.js"></script>
</script>
</html>