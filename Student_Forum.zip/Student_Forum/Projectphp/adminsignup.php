<!DOCTYPE html>
<?php
	session_start();
	include('dbconn.php');
	if (isset($_POST['submit'])) {
		    $name = $_POST['admname'];
			$email = $_POST['admemail'];

		$_SESSION['name'] = $name;
		$_SESSION['email'] = $email;
		}
?>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title></title>
	<link rel="stylesheet" type="text/css" href="./css/bootstrap.min.css">
	<style type="text/css">
		#title1{font-family: cursive; font-weight: bold;	margin-left: 20px;}
		#title{font-family: cursive; font-weight: bold;}
		#adm{
			width:500px;
			height:620px;
			margin-top: 9%;
			border: 1px solid gray;
			border-radius: 20px;	
			padding: 40px;
			padding-top: 25px;
			background-color: white;
		}
	</style>
</head>
<body style="background-color: lightgray">
<?php
	if (isset($_POST['submit'])) {
	    $name = $_POST['admname'];
		$email = $_POST['admemail'];
	    $pw = $_POST['admpass'];

	    $query = "INSERT INTO admintable(AId,AName,AEmail,APassword) VALUES('','$name','$email','$pw')";
	    $result = mysqli_query($db, $query);

	    if ($result) {
	            header('Location: adminprofile.php?Signupsuccessful');
	            exit();
	        } else {
	        	echo '<script>alert("Try again!");</script>';
	            exit();
	        }
	    }
?>
	 
	
	<center>
	<div id="adm">
	<a href="home.php"><button class="btn btn-close float-end"></button></a>
	<h3 id="title1">Admin Sign up</h3>
	<img src="./image/administrator.png" width="120px" height="120px" style="margin-top:20px;margin-bottom:10px;">
		<form class="pt-4" method="post">
			<label id="title" class="float-start">Name</label>
			<input class="form-control mb-3 w-100" type="text" name="admname" placeholder="">

			<label id="title" class="float-start">Email</label>
			<input class="form-control mb-2 w-100" type="email" name="admemail" placeholder="">

			<label id="title" class="float-start">Password</label>
			<input class="form-control mb-3 w-100" type="password" name="admpass" placeholder="">
			<div class="">
				<input class="btn btn-outline-secondary mt-4 w-75" type="submit" name="submit" value="Sign up"><br>
				<input class="btn btn-outline-secondary mt-2 w-75" type="reset" name="cancel" placeholder="Cancel">
			</div>
		</form>
	</div>
	</center>
</body>
</html>