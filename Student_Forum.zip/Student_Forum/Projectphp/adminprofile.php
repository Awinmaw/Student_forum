<!DOCTYPE html>
<?php 
session_start();
  include("dbconn.php");
   if (isset($_POST['upload'])){

    $writer=$_POST['uadmin'];
    $topic=$_POST['utopic'];
    $text=$_POST['utext'];
    $date=date('Y-m-d');
    $query="insert into adminpost(ID,Name,Topic,Information,Date) values ('','$writer','$topic' , '$text' , '$date')";
     mysqli_query($db, $query);

    if($query==true){
      echo "<script>alert('Post uploaded!');</script>";
    }
    else{
      echo "<script>alert('Failed to upload!');</script>";
    }
  }
?>

<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="./fontawesome-free-6.4.2-web/css/all.css">
    <link rel="stylesheet" href="./css/bootstrap.css">
    <style>
      .navbar{height: 70px; background-color: white; border-bottom: 1px solid gray; width: auto;}
      .top-nav a{color: black; margin-top: 5px; margin-left: 40px;}

      /* ::-webkit-scrollbar{width: 15px;} */
      /* ::-webkit-scrollbar-thumb{background-color: pink;}
      ::-webkit-scrollbar-track{background-color: #5597dd;}
      /* .active{border-bottom: 3px solid blue;} */
      .active{border-bottom: 3px solid blue;}
      .top-nav a:hover{border-bottom: 3px solid blue; }

      .bot-nav{width: 100%; position: fixed; bottom: 0; border-top: 2px solid gray; background-color: white; height: 60px; overflow: hidden;}

      .logo{font-size: 25px; margin-left: 550px; text-shadow: 2px 2px 3px lightgray;}
        .left-top{margin-top: 0px; padding-left: 70px; padding-right: 70px; padding-top: 20px; height: 370px;}
        .profilepic{width: 120px; height: 120px; margin: auto;}
        .profilepic img{width: 110px; height: 110px; object-fit: cover; margin-top: 10px;}
        .left-bottom button{width: 300px; font-size: 15px; padding: 10px; border: none;}

        .main-left{height: 660px; width: 35%; position: fixed; border-radius: 20px; margin-left: 45px; margin-top: 35px;}
        .main-right{margin-left: 610px; margin-right: 20px;}
        th{font-size: 18px; font-family: 'Courier New', Courier, monospace;}
        table{font-family: Arial, Helvetica, sans-serif; font-size: 15px; margin-left: 2%;}
        #searchbar{width: 100%; border-bottom: 1px solid lightgray; position: fixed; top: 4%; height: 500px; background-color: white; z-index: 5;}
        .right-bottom{margin-top: 51%;}
        .input{margin-left: 70px; margin-top: 10px;}

</style>
</head>
<body class="overflow-x-hidden bg-light">
    <!-- navbar-start -->
    <nav class="navbar navbar-expand-md shadow-sm sticky-top" id="navbar">
        <div class="container-fluid">
          <img src="./image/logo.png" style="width: 60px; height:60px; margin-left: 10px;">
          <span class="logo" href="#">ပညာဝေဆာ "သီရိခေတ္တရာ"</span>
          <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon" id="navbar1" ></span>
          </button>
          <div class="top-nav collapse navbar-collapse bg-white justify-content-end" id="navbarNav">
            
              <div class="form-check form-switch d-inline-block" style="margin-left: 100px;">
                <input type="checkbox" class="form-check-input" id="darkModeSwitch" onclick="openbtn()" onkeydown="closebtn()">
                <label class="form-check-label" for="darkModeSwitch"></label>
              </div>
          </div>
        </div>
      </nav>  
    <!-- navbar-end -->

      <div class="main-left" id="main-left" style="background-color: lightgray;">
        <div class="">
            <div class="left-top">
                  <h4><?php echo $_SESSION['name']."'s profile"; ?></h4>
                <div class="border border-primary "></div>
                  
                  <div class="card mt-4 ps-3 pe-3 pt-2 pb-2" aria-hidden="true">
                    <div class="profilepic"><img src="./image/default-user.png"></div>

                    <div class="card-body">
                      <h6><?php echo "Admin Name - ".$_SESSION['name']; ?></h6>
                      <h6><?php echo "Email - <span class='text-primary'>".$_SESSION['email']."</span>"; ?></h6>
                      <a href="adminlogin.php" name="view"><button class="btn btn-primary btn-sm text-light w-100 mt-2">Log out</button></a>
                    </div>
                    
                  </div>
            </div>
            <div class="border"></div>

            <div class="left-bottom ps-5 pe-5 pt-4">
                <h6 class="" style="color: gray;">Activity</h6>
                <a href="home.php"><button class="btn btn-outline-light w-100 mt-3 mb-1 text-lg-start text-black"><i class="fa-solid fa-chevron-up fa-rotate-90 me-3" style="color: gray;"></i><i class="fa-solid fa-house me-2 text-primary"></i>Home</button></a><br>
                <a href="postcontroladmin.php" style="text-decoration:none; color: black"><button class="btn btn-outline-light w-100 mb-1 text-lg-start text-black" type="button"><i class="fa-solid fa-chevron-up fa-rotate-90 me-3" style="color: gray;"></i><i class="fa-solid fa-bars-progress me-2 text-primary"></i>Manipulate Post</button></a><br>
                <a href="acccontroladmin.php" style="text-decoration:none; color: black"><button class="btn btn-outline-light w-100 mb-1 text-lg-start text-black" type="button"><i class="fa-solid fa-chevron-up fa-rotate-90 me-3" style="color: gray;"></i><i class="fa-solid fa-bars-progress me-2 text-primary"></i>Manipulate Account</button></a><br>
                <a href="adminlogin.php"><button class="btn btn-outline-light w-100 mb-1 text-lg-start text-black"><i class="fa-solid fa-chevron-up fa-rotate-90 me-3" style="color: gray;"></i><i class="fa-solid fa-right-from-bracket me-2 text-primary"></i>Log out</button></a>
            </div>
        </div>
    </div>
    
    <div class="bot-nav p-0 z-1 bg-light">
      <div class="">
        <span class="d-inline-block mt-3 ms-3">
        <?php
                      // Assuming you already have a database connection in $db

                      $query = "SELECT * FROM admintable";
                      $result = mysqli_query($db, $query);

                      if ($result) {
                          // Count the number of rows in the result set
                          $rowCount = mysqli_num_rows($result);

                          // Output the row count
                          echo "<h5>"."{$rowCount} Admin"."</h5>";

                          // Rest of your code to process the result set
                          while ($row = mysqli_fetch_assoc($result)) {
                              // Process each row as needed
                              // Example: echo $row['column_name'];
                          }

                          // Free the result set
                          mysqli_free_result($result);
                      } else {
                          // Handle the case where the query fails
                          echo "Query failed: " . mysqli_error($db);
                      }

                      // Close the database connection
                      mysqli_close($db);
                      ?>
        </span>
        <div id="dateContainer" class="d-inline-block float-end mt-3 me-3" >
          <script>
            // Get the current date
            var today = new Date();
        
            // Format the date as desired
            var formattedDate = today.toLocaleDateString('en-US', { year: 'numeric', month: 'long', day: 'numeric' });
        
            // Get the div element by its ID
            var dateContainer = document.getElementById('dateContainer');
        
            // Update the content of the div with the formatted date
            dateContainer.innerHTML =formattedDate;
        </script>
        </div>
      </div>
    </div>
    <div class="main-right pt-5" id="main-right">
       <div class="container-fluid">
        <div class="row">
          <div class="col-md-12 col-md-6 mb-5">
            
            <form method="POST">
              <div id="searchbar" class="bg-light">
              <div class="" style="width: 600px; height: 400px; margin-top: 80px; margin-left: 10%; background-color:white; border:1px solid gray; border-radius: 15px;">      
              <h4 class="mt-3 ms-3 mb-5">Post here!</h4>
                  <select name="uadmin" class="input form-select w-75 mb-2">
                    <option value="Admin" class="active">Admin</option>
                    <option value="Admin1" class="">Admin1</option>
                    <option value="Admin2" class="">Admin2</option>
                    <option value="Admin3" class="">Admin3</option>
                    <option value="Admin4" class="">Admin4</option>
                    <option value="Admin5" class="">Admin5</option>
                    <option value="Admin6" class="">Admin6</option>
                  </select>
                  <select name="utopic" class="input form-select w-75 mb-2">
                    <option value="" class="active">Choose your content..</option>
                    <option value="Contents Sharing">Contents Sharing</option>
                    <option value="Knowledge Sharing">Knowledge Sharing</option>
                    <option value="Breaking News">Breaking News</option>
                    <option value="Attended facts">Attended facts</option>
                  </select>
                  <textarea name="utext" class="txtarea form-control h-25 w-75 mt-4" style="border: 1px solid gray; margin-left:12%"></textarea>
                  <div class="btn-container d-flex w-75 mt-4 mb-5" style="margin-left:12%">
                    <button class="btn btn-outline-primary w-75 m-1" type="submit" name="upload">Upload</button>
                    <button class="btn btn-outline-primary w-75 m-1" type="reset" data-bs-dismiss="offcanvas">Reset</button>
                  </div>
                </div>
              </div>
            </form>

                <div class="right-bottom ">
                <table class="table w-100 mb-4 table-bordered table-striped">
                    <tr class="table-info" align="center">
                        <th>Id</th>
                        <th>Name</th>
                        <th>Email</th>
                        <th>Function</th>
                    </tr>
    
                    <?php
                        include('dbconn.php');
                        $query = "select * from admintable";
                        $result = mysqli_query($db,$query);
                        if($result){
                            while($data = mysqli_fetch_assoc($result)){
                              $Id = $data['AId'];
                              $Name = $data['AName'];
                              $Email = $data['AEmail'];
                              
                              echo '<tr>
                                      <td align="center">'.$Id.'</td>
                                      <td>'.$Name.'</td>
                                      <td>'.$Email.'</td>
                                      <td align="center">
                                      <button class="btn btn-outline-light btn-sm border border-danger"><a style="text-decoration:none; color:red" href="deleteadmin.php?deleteId='.$Id.'">Delete<i style="color:red" class="fa-solid fa-trash ms-1"></i></a></button></td>
                                  </tr>';
                        }
                    }
                    ?>
                  </table>
                </div>

            </div>
            
          </div> 
      </div>
       </div>
    </div>
</body>
<script src="./js/bootstrap.js"></script>
<script>
  function openbtn(){
      document.getElementById('main-left').style.backgroundColor = "rgba(0,0,100,0.4)";
      document.getElementById('main-right').style.backgroundColor = "rgba(0,0,100,0.4)";
      document.body.style.backgroundColor = "rgba(0,0,100,0.4)";
    }
    function closebtn(){
      document.getElementById('main-left').style.backgroundColor = "";
      document.getElementById('main-right').style.backgroundColor = "";
      document.body.style.backgroundColor = "";
    }
</script>
<script>
    // Get the current date
    var today = new Date();
        
    // Format the date as desired
    var formattedDate = today.toLocaleDateString('en-US', { year: 'numeric', month: 'long', day: 'numeric' });
        
    // Get the div element by its ID
    var dateContainer = document.getElementById('dateContainer');
        
    // Update the content of the div with the formatted date
    dateContainer.innerHTML =formattedDate;
</script>
</html>