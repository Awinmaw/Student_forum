<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
<?php
include('dbconn.php');
    if(isset($_GET['delId'])){
        $Id = $_GET['delId'];

        $query = "delete from posttable where PostId = $Id";
        mysqli_query($db,$query);

        if($query){
            header('location:postcontroladmin.php');
        }
        else{
            die(mysqli_connect_error($db));
        }
    }
?>
</body>
</html>