<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <?php
        include('dbconn.php');
        if(isset($_GET['deleteId'])){
            $Id = $_GET['deleteId'];

            $query = "delete from userinfo where UId=$Id";
            mysqli_query($db,$query);

            if($query == true){
                header('location:acccontroladmin.php');
            }
            else{
                die(mysqli_connect_error($db));
            }
        }
    ?>
</body>
</html>