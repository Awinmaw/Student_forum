<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" href="./css/bootstrap.css">
	<title></title>
</head>
<body>
	<?php 
		include('dbconn.php');
		$id=$_GET['apprId'];
		$sql="select * from posttable where PostId=$id";
		$result=mysqli_query($db,$sql);
		$row=mysqli_fetch_assoc($result);
		$id=$row['PostId'];
		$wid=$row['Postwriter'];
		$tp=$row['PostTopic'];
		$post=$row['PostContent'];
		$date=$row['PostDate'];
		$st=$row['Status'];

		if (isset($_POST['submit'])) {
			$query = "UPDATE posttable SET Status=1 WHERE PostId=$id";
			mysqli_query($db,$query);
			if ($query==true) {
				header('Location:postcontroladmin.php');
			}
			else
			{
				header('Location:approve.php');
			}
		}
	 ?>
	 <form method="post" action="">
	 	<input type="submit" name="submit" class="btn btn-primary ms-3 mt-3" value="Click to approve!">
	 </form>
</body>
</html>
