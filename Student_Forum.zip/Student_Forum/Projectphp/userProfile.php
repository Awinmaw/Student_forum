<!DOCTYPE html>
<?php
session_start();

// Check if the user is logged in
if (!isset($_SESSION['uname']) || !isset($_SESSION['upk'])) {
    // If not logged in, redirect to the login page
    header('Location: mylogin.php');
    exit();
}

// Retrieve session variables
$_SESSION['uname'];
$_SESSION['upk'];
$_SESSION['uyr'];
 $_SESSION['uem'];

// Handle logout
if (isset($_POST['logout'])) {
    // Destroy the session
    session_destroy();
    // Redirect to login page
    header('Location: mylogin.php');
    exit();
}

if (isset($_POST['view'])) {
    $name = $_SESSION['uname'];
    $pakapata = $_SESSION['upk'];
    $year = $_SESSION['uyr'];
    $email = $_SESSION['uem'];
}
else{
  header('location:mylogin.php');
}
?>

<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="./css/bootstrap.css">
    <style>
        .navbar{height: 70px; background-color: white; border-bottom: 1px solid gray; width: auto;}
        .top-nav a{color: black; margin-top: 5px; margin-left: 40px;}
        .top-nav a:hover{border-bottom: 3px solid blue; width: auto;}
        .active{border-bottom: 3px solid blue;}
        .logo{font-size: 25px; margin-left: 550px; text-shadow: 2px 2px 3px lightgray;}        .main{width: 40%; height: 100vh; position: fixed; margin-left: 30%; padding-top: 15px;}
        .card{margin: 60px; height: 660px;}
        .profile{box-shadow:1px 1px 3px #5597dd; border-radius: 30px;}
        .profile-pic{border-radius: 20px; padding: 20px;}
        .profile-pic img{width: 160px; height: 160px; margin-left: 28%; border-radius: 100%; border: 2px solid blue;}

        .tabl{margin-top: 30px;}
        .tabl tr{height: 60px;}
        .tabl div{border-radius: 30px; height: 35px; padding-left: 10px; padding-top: 2px;border: 1px solid lightgray; border-radius: 50px;}
    </style>
</head>
<body style="overflow: hidden;" class="bg-light">
    <!-- navbar-start -->
    <nav class="navbar navbar-expand-md shadow-sm sticky-top" id="navbar">
    <div class="container-fluid">
          <img src="./image/logo.png" style="width: 60px; height:60px; margin-left: 10px;">
          <span class="logo" href="#">ပညာဝေဆာ "သီရိခေတ္တရာ"</span>
          <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon" id="navbar1" ></span>
          </button>
          <div class="top-nav collapse navbar-collapse bg-white justify-content-end" id="navbarNav">
            <!-- <ul class="navbar-nav" id="navbar2">
              <li class="nav-item">
                <a class="nav-link active" aria-current="page" href="home.php">Home</a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="#project">About</a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="#portfolio">Help</a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="#contact">Contact</a>
              </li>
            </ul> -->
              <div class="form-check form-switch d-inline-block" style="margin-left: 100px;">
                <input type="checkbox" class="form-check-input" id="darkModeSwitch" onclick="openbtn()" onkeydown="closebtn()">
                <label class="form-check-label" for="darkModeSwitch"></label>
              </div>
          </div>
        </div>
      </nav>
    <!-- navbar-end -->
    <div class="main">
        <div class="profile card p-0">
            <div class="card-body p-4">
                <div class="profile-pic bg-light"><img src="./image/default-user.png"></div>

                <div class="tabl">                 
                  <hr><br>
                    <label class="float-start fw-bold fs-6">Name : </label>
                    <div class="d-inline-block w-75 float-end"><?php echo $name;?></div><br><br>
                    <label class="float-start fw-bold fs-6">Email : </label>
                    <div class="d-inline-block w-75 float-end"><?php echo $email;?></div><br><br>
                    <label class="float-start fw-bold fs-6">Acdemic Year : </label>
                    <div class="d-inline-block w-75 float-end"><?php echo $year;?></div><br><br>
                    <label class="float-start fw-bold fs-6">PAKAPATA : </label>
                    <div class="d-inline-block w-75 float-end"><?php echo $pakapata;?></div><br><br><hr>
                </div>
                
                <div align="center">
                  <form action="mylogin.php" method="post">
                    <a style="color:white; text-decoration: none" name="logout"><button class="btn btn-md btn-primary mt-3 w-75">Log out</button></a>
                  </form>
                  <a style="color:white; text-decoration: none" href="upload.php"><button class="btn btn-md btn-primary mt-2 w-75">cancel</button></a>
                </div>
            </div>
        </div>
    </div>
</body>
<script></script>
<script>
    // Get the current date
    var today = new Date();
        
    // Format the date as desired
    var formattedDate = today.toLocaleDateString('en-US', { year: 'numeric', month: 'long', day: 'numeric' });
        
    // Get the div element by its ID
    var dateContainer = document.getElementById('dateContainer');
        
    // Update the content of the div with the formatted date
    dateContainer.innerHTML =formattedDate;
</script>
</html>