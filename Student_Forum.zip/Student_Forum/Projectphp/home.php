<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="footer.css">
    <link rel="stylesheet" href="./fontawesome-free-6.4.2-web/css/all.min.css">
	<script src="js/bootstrap.min.js"></script>
    <style>
        *{
            padding:0;
            margin:0;
        }
        body{
            background-image: url('./image/bg.jpg');
            width:100%;
            height:100%;
            background-attachment:fixed;
            background-position: center center;
            background-size:cover;
        }
        .let{
            width:60%;
            height:100%;
            margin-left:20%;
            margin-top:300px;
            color: rgba(0,188,212);
            text-align:center;
        }
        .aa{
            margin-left:43%;
            margin-top:70px;
        }
    </style>
</head>
<body>
    <nav class="navbar navbar-expand-lg bg-body-tertiary">
		<div class="container-fluid">
			<img src="./image/logo.png" alt="" width="70px">
		   <h3 style="margin-left:250px;">ပညာဝေဆာ "သီရိခေတ္တရာ"</h3>
           <div class="btn-group btn-outline-primary">
				<!-- <a href="home.php" class="btn btn-success active" aria-current="page">Home</a> -->
				<a href="register.php" class="btn btn-outline-primary ms-1">Sign Up</a>
				<a href="mylogin.php" class="btn btn-outline-primary ms-1">Login</a>
                <a href="adminsignup.php" class="btn btn-outline-primary  ms-1">Admin Sign up</a>
                <a href="adminlogin.php" class="btn btn-outline-primary  ms-1">Admin Login</a>
			  </div>

		  </div>
		</div>
	  </nav>
        <h1 class="let">Join Univesity Of Computer Studies Pyay's Student Forum</h1>
        <div class="aa" >
            <a href="register.php"><button class="btn btn-light text-black">Sign up</button></a>
            <a href="mylogin.php"><button class="btn btn-light text-black">Login</button></a>
        </div>

        <div class="container-fluid bg-light" id="foot" style="position:absolute;top:100%;width:100%;">
            <div class="row" style="border-top:2px solid #22668D;">
    
                <div class="col-sm-4" id="left" align="center">
                    <h1>Contact</h1>
                    <div class="l1">
                        <label><a href="mailto:winpapaminn@gmail.com"><i class="fa-solid fa-envelope-open-text fa-2xl text-primary"></i></a></label>
                    </div>
                    <div class="l2">
                         <label><a href="tel:+959660113312"><i class="fa-solid fa-square-phone fa-2xl" style="color: #38ee2b;"></i></i></a></label>
    
                    </div>
                    <div class="l3">
                        <label><a href=""><i class="fa-brands fa-square-facebook fa-2xl text-primary"></i></a></label>
                    </div>
                    <div class="l4">
                         <label><a href=""><i class="fa-brands fa-instagram fa-2xl text" style="color: #de1b1b;"></i></a></label>
                    </div>
                </div>
    
            <div class="col-sm-4" id="mid" align="center">
                <h1>Go To</h1>
                <a href="home.php"><u>Home</u></a>
                <a href="">Feed</a>
                <a href="adminsignup.php">Admin signup</a>
                <a href="adminlogin.php">Admin Login</a>
                <a href="">Contact Us</a>
                <a href="">Support Us</a>
                <a href="">Get Help and Support</a>
            </div>
            <div class="col-sm-4" id="right" align="center">
                <h1>Support Team<a href="" ><img src="./image/coding.png" width="50px"></a> </h1>
                <a href="mailto:khanthmupaing@gmail.com">Khant Hmu Paing</a>
                <a href="mailto:mawkoonhain@gmail.com">Maw Koon Hein</a>
                <a href="mailto:winpapamin@gmail.com">Win Pa Pa Min</a>
                <a href="mailto:papawinthwin@gmail.com">Pa Pa Win Thwin</a>
            </div>
        </div>
        <div class="row text-white" style="background-color:#22668D;height:60px;">
                <div class="col-12" align="center">
                      <a href="https://www.google.com/maps?q=18.8229,95.2556"><img src="./image/placeholder.png" class="mt-2" width="45px" height="45px" class="mt-1"></a><label>Pyay Aung Lan Main Road, Pyay Wetern</label>
                </div>
        </div>
        <div class="row">
            <div class="col-12 pt-1" align="center" style="background-color:powderblue;height:45px;">
                <h3 class="cp">&copy 2024 ucspyay, this forum is for school.</h3>
            </div>
        </div>
        </div>
</body>
</html>