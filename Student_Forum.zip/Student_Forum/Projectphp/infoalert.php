<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title></title>
</head>
<body>
	<h1>Admin Information Are not correct</h1>
	<button>
		<a href="adminlogin.php">Relogin Here</a>
	</button>
</body>
</html>